const bar = { name:'bar', type:'spam', age:0 };
export default bar;
