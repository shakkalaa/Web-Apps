import bar from './bar.js';
console.log(bar);